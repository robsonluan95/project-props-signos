import React from 'react';
import './estilo.css';

export default function Titulo() {
  return (
    <div className="box">
      <p className="texto">Baralho dos Signos</p>
    </div>
  )
}

